package ec.edu.ups.bibliotecadao.dao;

import java.util.List;

import ec.edu.ups.bibliotecadao.idaos.ILibroDAO;
import ec.edu.ups.bibliotecadao.modelos.Libro;

public class LibroDAO implements ILibroDAO {
	
	private List<Libro> listaLibros;
	
	public LibroDAO() {
		
	}

	@Override
	public void agregarLibro(Libro libro) {
		listaLibros.add(libro);
	}

	@Override
	public Libro obtenerLibro(String titulo) {
        for (Libro libro : listaLibros) {
            if (libro.getTitulo().equals(titulo)) {
                return libro;
            }
        }
        return null;
    }

	@Override
	public List<Libro> obtenerTodosLosLibros() {
		return listaLibros;
	}

	@Override
	public boolean actualizarLibro(Libro libro) {
	    for (int i = 0; i < listaLibros.size(); i++) {
	        Libro libroEncontrado = listaLibros.get(i);
	        if (libroEncontrado.getTitulo().equals(libro.getTitulo())) {
	            libroEncontrado.setTitulo(libro.getTitulo());
	            libroEncontrado.setAutor(libro.getAutor());
	            return true;
	        }
	    }
		return false;
	}	


	@Override
	public boolean eliminarLibro(String titulo) {
		for(int i=0; i < listaLibros.size() ;i++) {
			Libro libro = listaLibros.get(i);
	        if (libro.getTitulo().equals(titulo)) {
	            listaLibros.remove(i);
	            return true;
	        }
	    }
		return false;
	}
}