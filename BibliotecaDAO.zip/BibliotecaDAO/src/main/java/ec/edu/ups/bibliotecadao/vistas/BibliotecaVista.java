package ec.edu.ups.bibliotecadao.vistas;

import java.util.Scanner;

import ec.edu.ups.bibliotecadao.modelos.Biblioteca;


public class BibliotecaVista {
	
	private Scanner entrada;

    public BibliotecaVista() {
        entrada = new Scanner(System.in);
    }
    
    public Biblioteca ingresarBiblioteca() {
    	System.out.println("---NUEVA BIBLIOTECA---");
    	System.out.println("Ingrese el nombre de la biblioteca: ");
    	String nombre = entrada.next();
    	System.out.println("Ingrese la calle de la biblioteca: ");
    	String calle = entrada.next();
    	
    	return new Biblioteca(nombre,calle);
    	
    }
    
    public String eliminarBiblioteca() {
    	System.out.println("------ELIMINAR BIBLIOTECA------");
        System.out.println("Ingresa el nombre de la biblioteca a eliminar");
        String nombre = entrada.next();
        return nombre;
    }
    
}



