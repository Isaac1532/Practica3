package ec.edu.ups.bibliotecadao.vistas;

import java.util.ArrayList;
import java.util.Scanner;

import ec.edu.ups.bibliotecadao.modelos.Prestamo;
import ec.edu.ups.bibliotecadao.modelos.Usuario;

public class UsuarioVista {

    private Scanner entrada;

    public UsuarioVista() {
        entrada = new Scanner(System.in);
    }

    public Usuario ingresarDatosUsuario() {
        System.out.println("------Ingreso de Nuevo Usuario------");
        System.out.println("Ingresa el nombre del usuario");
        String nombre = entrada.next();
        System.out.println("Ingresa la identificación del usuario");
        String identificacion = entrada.next();
        System.out.println("Ingresa el correo del usuario");
        String correo = entrada.next();

       
        ArrayList<Prestamo> prestamos = new ArrayList<>();

        return new Usuario(nombre, identificacion, correo, prestamos);
    }


    public String eliminarDatosUsuario() {
        System.out.println("------Eliminar Usuario------");
        System.out.println("Ingresa la identificación del usuario a eliminar");
        String identificacion = entrada.next();
        return identificacion;
    }

}
