package ec.edu.ups.bibliotecadao.controladores;

import java.util.List;

import ec.edu.ups.bibliotecadao.idaos.ILibroDAO;
import ec.edu.ups.bibliotecadao.modelos.Libro;
import ec.edu.ups.bibliotecadao.vistas.LibroVista;

public class LibroControlador {
    
}


