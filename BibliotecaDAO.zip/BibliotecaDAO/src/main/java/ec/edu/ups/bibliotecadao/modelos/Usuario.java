package ec.edu.ups.bibliotecadao.modelos;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Usuario extends Persona {
	
	private String correo;
	private ArrayList<Prestamo> prestamos;
	
	public Usuario(String nombre, String identificacion, String correo, ArrayList<Prestamo> prestamos) {
		super(nombre, identificacion);
		this.correo = correo;
		this.prestamos = prestamos;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(correo, prestamos);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		return Objects.equals(correo, other.correo) && Objects.equals(prestamos, other.prestamos);
	}

	@Override
	public String toString() {
		return "Usuario [correo=" + correo + ", prestamos=" + prestamos + "]";
	}

}
