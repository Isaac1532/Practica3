package ec.edu.ups.bibliotecadao.modelos;

import java.util.Objects;

import ec.edu.ups.bibliotecadao.idaos.Prestable;

public class Libro implements Prestable {
	
	private String titulo;
	private String autor;
	private int año;
	private boolean disponible;
	
	

	public Libro(String titulo, String autor, int año) {
		super();
		this.titulo = titulo;
		this.autor = autor;
		this.año = año;
		
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public int getAño() {
		return año;
	}

	public void setAño(int año) {
		this.año = año;
	}

	public boolean isDisponible() {
		return disponible;
	}

	public void setDisponible(boolean disponible) {
		this.disponible = disponible;
	}

	@Override
	public int hashCode() {
		return Objects.hash(autor, año, disponible, titulo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Libro other = (Libro) obj;
		return Objects.equals(autor, other.autor) && año == other.año && disponible == other.disponible
				&& Objects.equals(titulo, other.titulo);
	}

	@Override
	public String toString() {
		return "Libro [titulo=" + titulo + ", autor=" + autor + ", año=" + año + ", disponible=" + disponible + "]";
	}

	@Override
	public void prestar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void devolver() {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
}
