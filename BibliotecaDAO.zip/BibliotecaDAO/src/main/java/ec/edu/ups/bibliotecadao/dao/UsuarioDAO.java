package ec.edu.ups.bibliotecadao.dao;

import java.util.List;

import ec.edu.ups.bibliotecadao.idaos.IUsuarioDAO;
import ec.edu.ups.bibliotecadao.modelos.Usuario;



public class UsuarioDAO implements IUsuarioDAO{
	
	private List<Usuario> listaUsuarios;
	
	public UsuarioDAO() {
		
	}

	@Override
	public void registrarUsuario(Usuario usuario) {
		listaUsuarios.add(usuario);
		
	}

	@Override
	public Usuario obtenerUsuario(String identificacion) {
	    for (Usuario usuario : listaUsuarios) {
	        if (usuario.getIdentificacion().equals(identificacion)) {
	            return usuario;
	        }
	    }
	    return null;
	}

	@Override
	public List<Usuario> obtenerTodosLosUsuarios() {
		return listaUsuarios;
	}

	@Override
	public boolean actualizarUsuario(Usuario usuario) {
	    for (int i = 0; i < listaUsuarios.size(); i++) {
	        Usuario usuarioEncontrado = listaUsuarios.get(i);
	        if (usuarioEncontrado.equals(i)) {
	            listaUsuarios.set(i, usuario);
	            return true;
	        }
	    }
	    return false;
	}


	@Override
	public boolean eliminarUsuario(Usuario usuario) {
		for (int i = 0; i < listaUsuarios.size(); i++) {
			Usuario usuarioo = listaUsuarios.get(i);
            if(usuarioo.getIdentificacion().equals(listaUsuarios.get(i))){
                listaUsuarios.remove(i);
                return true;
            }
            
        }
        return false;
    }
    
}
