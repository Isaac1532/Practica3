package ec.edu.ups.bibliotecadao.vistas;

import java.util.Scanner;

import ec.edu.ups.bibliotecadao.modelos.Libro;

public class LibroVista {
    private Scanner entrada;

    public LibroVista() {
        entrada = new Scanner(System.in);
    }

    public Libro ingresarDatosLibro() {
        System.out.println("------Ingreso del nuevo Libro------");
        System.out.println("Ingresa el título del nuevo Libro");
        String titulo = entrada.next();
        System.out.println("Ingresa el autor del nuevo Libro");
        String autor = entrada.next();
        System.out.println("Ingresa el año del nuevo Libro");
        int año = entrada.nextInt();

        return new Libro(titulo, autor, año);
    }

    public Libro actualizarDatosLibro() {
        System.out.println("------Actualizar Libro------");
        System.out.println("Ingresa el título a actualizar");
        String titulo = entrada.next();
        System.out.println("Ingresa el autor a actualizar");
        String autor = entrada.next();
        System.out.println("Ingresa el año a actualizar");
        int año = entrada.nextInt();

        return new Libro(titulo, autor, año);
    }

    public String eliminarLibro() {
        System.out.println("------Eliminar Libro------");
        System.out.println("Ingresa el título a eliminar");
        String titulo = entrada.next();
        return titulo;
    }

}



