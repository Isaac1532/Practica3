package ec.edu.ups.bibliotecadao.modelos;

import java.util.Date;
import java.util.Objects;

public class Prestamo {
	private int id;
	private Libro libro;
	private Usuario usuario;
	private Date fechaPrestamo;
	private Date fechaDevolucion;
	
	public Prestamo(int id) {		
		this.id = id;
		
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Libro getLibro() {
		return libro;
	}

	public void setLibro(Libro libro) {
		this.libro = libro;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Date getFechaPrestamo() {
		return fechaPrestamo;
	}

	public void setFechaPrestamo(Date fechaPrestamo) {
		this.fechaPrestamo = fechaPrestamo;
	}

	public Date getFechaDevolucion() {
		return fechaDevolucion;
	}

	public void setFechaDevolucion(Date fechaDevolucion) {
		this.fechaDevolucion = fechaDevolucion;
	}

	@Override
	public int hashCode() {
		return Objects.hash(fechaDevolucion, fechaPrestamo, id, libro, usuario);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Prestamo other = (Prestamo) obj;
		return Objects.equals(fechaDevolucion, other.fechaDevolucion)
				&& Objects.equals(fechaPrestamo, other.fechaPrestamo) && id == other.id
				&& Objects.equals(libro, other.libro) && Objects.equals(usuario, other.usuario);
	}

	@Override
	public String toString() {
		return "Prestamo [id=" + id + ", libro=" + libro + ", usuario=" + usuario + ", fechaPrestamo=" + fechaPrestamo
				+ ", fechaDevolucion=" + fechaDevolucion + "]";
	}
	
	

}