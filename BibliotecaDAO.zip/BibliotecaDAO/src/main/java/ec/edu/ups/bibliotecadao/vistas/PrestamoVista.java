package ec.edu.ups.bibliotecadao.vistas;

import java.util.Scanner;

import ec.edu.ups.bibliotecadao.modelos.Prestamo;

public class PrestamoVista {

    private Scanner entrada;

    public PrestamoVista() {
        entrada = new Scanner(System.in);
    }

    public Prestamo ingresarDatosPrestamo() {
        System.out.println("------Ingreso de Nuevo Préstamo------");
        System.out.println("Ingresa el ID del préstamo");
        int id = entrada.nextInt();
        return new Prestamo(id);
    }

    public int eliminarDatosPrestamo() {
        System.out.println("------Eliminar Préstamo------");
        System.out.println("Ingresa el ID del préstamo a eliminar");
        int idPrestamo = entrada.nextInt();
        return idPrestamo;
    }

}