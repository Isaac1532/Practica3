package ec.edu.ups.bibliotecadao.controladores;

import java.util.List;

import ec.edu.ups.bibliotecadao.dao.BibliotecaDAO;
import ec.edu.ups.bibliotecadao.idaos.IBibliotecaDAO;
import ec.edu.ups.bibliotecadao.modelos.Biblioteca;
import ec.edu.ups.bibliotecadao.modelos.Libro;
import ec.edu.ups.bibliotecadao.vistas.BibliotecaVista;

import java.util.List;

public class BibliotecaControlador {
    private IBibliotecaDAO bibliotecaDAO;
    private BibliotecaVista bibliotecaVista;
    private Biblioteca biblioteca;
	
    public BibliotecaControlador(IBibliotecaDAO bibliotecaDAO, BibliotecaVista bibliotecaVista, Biblioteca biblioteca) {		
		this.bibliotecaDAO = bibliotecaDAO;
		this.bibliotecaVista = bibliotecaVista;
		this.biblioteca = biblioteca;
	}
    
    public void crearBiblioteca() {
    	 this.biblioteca=new Biblioteca("Biblioteca Central","Calle Simon Bolivar");
    }
    
    public List<Libro> verLibros(){
    	List<Libro> = BibliotecaDAO.obtenerBiblioteca;
    }
    
}



   


