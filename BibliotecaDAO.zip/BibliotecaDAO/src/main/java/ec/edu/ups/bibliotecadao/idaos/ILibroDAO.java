package ec.edu.ups.bibliotecadao.idaos;

import java.util.List;

import ec.edu.ups.bibliotecadao.modelos.Libro;

public interface ILibroDAO {

    // Métodos CRUD para Libros
    void agregarLibro(Libro libro);
    Libro obtenerLibro(String titulo);
    List<Libro> obtenerTodosLosLibros();
    boolean actualizarLibro(Libro libro);
    boolean eliminarLibro(String titulo);

   
}
