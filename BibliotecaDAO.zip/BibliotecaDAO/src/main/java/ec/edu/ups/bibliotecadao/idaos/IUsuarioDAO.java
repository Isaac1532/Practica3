package ec.edu.ups.bibliotecadao.idaos;

import java.util.List;

import ec.edu.ups.bibliotecadao.modelos.Usuario;

public interface IUsuarioDAO {

    // Métodos CRUD para Usuarios
    void registrarUsuario(Usuario usuario);
    Usuario obtenerUsuario(String identificacion);
    List<Usuario> obtenerTodosLosUsuarios();
    boolean actualizarUsuario(Usuario usuario);
    boolean eliminarUsuario(Usuario usuario);

    
}
