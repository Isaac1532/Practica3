package ec.edu.ups.bibliotecadao.idaos;

public interface Prestable {
	
	void prestar();
	void devolver();

}
