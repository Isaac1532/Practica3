package ec.edu.ups.bibliotecadao.dao;

import java.util.ArrayList;
import java.util.List;

import ec.edu.ups.bibliotecadao.idaos.IBibliotecaDAO;
import ec.edu.ups.bibliotecadao.modelos.Biblioteca;


public class BibliotecaDAO implements IBibliotecaDAO {
	
	private List<Biblioteca> listaBibliotecas;
	
	public BibliotecaDAO() {
		listaBibliotecas = new ArrayList();
	}

	@Override
	public List<Biblioteca> obtenerBibliotecas() {
		return listaBibliotecas;
	}

	@Override
	public Biblioteca obtenerBiblioteca(String nombre) {
		for(Biblioteca biblioteca : listaBibliotecas) {
			if(biblioteca.getNombre().equals(nombre)) {
				return biblioteca;
			}
		}
		return null;
	}

	@Override
	public void crearBiblioteca(Biblioteca biblioteca) {
		listaBibliotecas.add(biblioteca);		
	}

	@Override
	public boolean actualizarBiblioteca(String nombre, String direccion) {
		for(int i=0; i < listaBibliotecas.size() ;i++) {
			Biblioteca bibliotecaEncontrada = listaBibliotecas.get(i);
	        if (bibliotecaEncontrada.getNombre().equals(nombre)) {
	            bibliotecaEncontrada.setDireccion(direccion);
	            return true;
	        }
	    }
		return false;
	}		


	@Override
	public boolean eliminarBiblioteca(String nombre) {
		for(int i=0; i < listaBibliotecas.size() ;i++) {
			Biblioteca biblioteca = listaBibliotecas.get(i);
	        if (biblioteca.getNombre().equals(nombre)) {
	            listaBibliotecas.remove(i);
	            return true;
	        }
	    }
		return false;
	}
}