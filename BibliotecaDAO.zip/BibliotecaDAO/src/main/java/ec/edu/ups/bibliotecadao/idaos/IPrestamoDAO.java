package ec.edu.ups.bibliotecadao.idaos;

import java.util.List;

import ec.edu.ups.bibliotecadao.modelos.Prestamo;

public interface IPrestamoDAO {

    // Métodos CRUD para Préstamos
    void registrarPrestamo(Prestamo prestamo);
    Prestamo obtenerPrestamo(int id);
    List<Prestamo> obtenerTodosLosPrestamos();
    void actualizarPrestamo(Prestamo prestamo);
    boolean eliminarPrestamo(int id);

 
}
