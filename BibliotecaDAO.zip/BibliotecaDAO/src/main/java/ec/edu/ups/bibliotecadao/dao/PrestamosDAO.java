package ec.edu.ups.bibliotecadao.dao;

import java.util.List;

import ec.edu.ups.bibliotecadao.idaos.IPrestamoDAO;

import ec.edu.ups.bibliotecadao.modelos.Prestamo;

public class PrestamosDAO implements IPrestamoDAO{
	
	private List<Prestamo> listaPrestamos;
	
	public PrestamosDAO() {
		
	}

	@Override
	public void registrarPrestamo(Prestamo prestamo) {
		listaPrestamos.add(prestamo);
		
	}

	@Override
	public Prestamo obtenerPrestamo(int id) {
		for (Prestamo prestamo : listaPrestamos) {
            if (prestamo.getId() == id) {
                return prestamo;
            }
        }
        return null;
    }
	

	@Override
	public List<Prestamo> obtenerTodosLosPrestamos() {
		return listaPrestamos;
	}

	@Override
	public void actualizarPrestamo(Prestamo prestamo) {
	    for (int i = 0; i < listaPrestamos.size(); i++) {
	        if (listaPrestamos.get(i).getId() == prestamo.getId()) {
	            listaPrestamos.set(i, prestamo);
	            return;
	        }
	    }
	}


	@Override
	public boolean eliminarPrestamo(int id) {
		for(int i=0; i < listaPrestamos.size() ;i++) {
			Prestamo prestamo = listaPrestamos.get(i);
	        if (prestamo.getId() == prestamo.getId()) {
	            listaPrestamos.remove(i);
	            return true;
	        }
	    }
		return false;
	}
}
